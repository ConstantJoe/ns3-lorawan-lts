// Copyright (c) 2013 Your Company. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef LIGHTWEIGHT_TIMESLOTS_H_
#define LIGHTWEIGHT_TIMESLOTS_H_

#include <tuple>
#include <vector>
#include <ns3/object.h>

#include <fftw3.h>

namespace ns3 {

struct Periodicity {
	int p, o, uID, change;
};

class LightweightTimeslots : public Object{
public:

  static TypeId GetTypeId (void);

  LightweightTimeslots();
  ~LightweightTimeslots();

  float TiComScore(std::tuple <int, int> s, std::vector<unsigned char>& Ps_star, std::vector<unsigned char>& O, float alpha, float abs_T, float abs_F);

  //std::vector<std::tuple <int, int>> TiComWithFFT(std::vector<unsigned char> O, float alpha);

  std::vector<std::tuple <int, int>> TiComWithAutocorrelation(std::vector<unsigned char>& O, float alpha);

  void Correlation(const std::vector<unsigned char>& x, const std::vector<unsigned char>& y, std::vector<float>& z);

  std::tuple<int, int> FindCandidateSolutionAutocorrelation(const std::vector<unsigned char>& O);

  //std::tuple<int, int> FindCandidateSolutionFFT(std::vector<unsigned char> O); 

  //std::tuple <int, int> ArgmaxOverList(std::vector<std::tuple <int, int>> S, std::vector<unsigned char> Ps_star, std::vector<unsigned char> O, float alpha, float abs_T, float abs_F);

  static int Main(int argc, const char** argv);

  void CollisionAvoidance(std::vector<Periodicity>& periodicities, float alpha);

  int lcm(int a, int b);

  float CalculatePercentageOverlap(int p1, int p2, int o1, int o2); 

  static bool sortByPthenO(Periodicity p1, Periodicity p2);

  void Run();

  float alpha;
  float slot_size; //2.793 for DR0;
  float periodicity;
  float offset;
  int time_slots;
  std::vector<unsigned char> O;

  std::vector<float> correlation_holder;

  fftw_complex *inX, *outX;
  fftw_plan pX;

  fftw_complex *inY, *outY;
  fftw_plan pY;

  fftw_complex *inZ, *outZ;
  fftw_plan pZ;

  static Ptr<LightweightTimeslots> m_lorawanLightweightTimeslotsPtr;
};

} // namespace ns3

#endif // LIGHTWEIGHT_TIMESLOTS_H_
