// Copyright (c) 2013 Your Company. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <iostream>
#include <exception>
#include <vector>
#include <algorithm>
#include <cmath>
#include <chrono>
#include <complex> 
#include <ns3/log.h>

#include "lightweight-timeslots.h"

#define PI 3.14159265

#define DEBUG 1

#define MAX_C 3 //DR dependent

/*

The scoring function of TiCom was used to judge the quality of (p, o) pairs.

TiCom does an exhaustive search for candidate solutions, which is not realistic here as there are many time slots. So we come up with a way of finding decent
quality candidate solutions, then do a quick search around the solutions with the scoring function to find the best fit.

First approach tried: FFT. But as the sequence is in the form of a pulse wave, there are many peaks in the FFT because the sine waves only approximate the squareness
of the wave

Second approach tried: Walsh spectrum. But Walsh spectrum is only applicable for square waves, and our sequence is not a square wave. And I couldn't find a way of
converting it to a square wave that wouldn't require prior knowledge of the periodicities.

Third approach tried: autocorrelation. Autocorrelation is not a sufficient approach by itself, but if we do a search with the scoring function around the result, and 
filter out matched values, then the results are good.

The third approach appears to work. But it is slow (0.08s per periodicity picked up in the sequence). Optimisation ideas:

TODO:
Factor in IDs in collision avoidance - all periodicities will have to change.if one change is proposed
Factor in MAX_C, which is DR dependant

Move over to ns-3

*/

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("LightWeightTimeslots");

NS_OBJECT_ENSURE_REGISTERED (LightweightTimeslots);

Ptr<LightweightTimeslots> LightweightTimeslots::m_lorawanLightweightTimeslotsPtr = NULL;

TypeId
LightweightTimeslots::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::LightWeightTimeslots")
    .SetParent<Object> ()
    .SetGroupName("LoRaWAN")
    .AddConstructor<LightweightTimeslots> ()
  ;
  return tid;
}

  LightweightTimeslots::LightweightTimeslots (void) {

  alpha = 0.8;
  slot_size = 0.118; //2.793 for DR0;
  periodicity = 989;
  offset = 564;
  time_slots = 30508;
  O = std::vector<unsigned char>(time_slots, 0); //1289 for DR0

  correlation_holder = std::vector<float>(O.size()*2 - 1);

  int total_c = 0;
  int total_c_wo_colls = 0;

  //generate input
  int inte = round(periodicity / slot_size);
  for(int x=0;x<int(time_slots / inte);x++) {
    O[inte * x + offset] = 1;
    total_c++;
    total_c_wo_colls++;
  }
  std::cout << "slots added: " << int(time_slots / inte) << std::endl;

  periodicity = 600;
  offset = 101;
  inte = round(periodicity / slot_size);
  for(int x=0;x<int(time_slots / inte);x++) {
    if(!O[inte * x + offset]) total_c_wo_colls++;

    O[inte * x + offset] = 1;
    total_c++;
  } 
  std::cout << "slots added: " << int(time_slots / inte) << std::endl;

  std::cout << "total 1s added: " << total_c << " and excluding collisions: " << total_c_wo_colls << std::endl;

  inX = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * (O.size() + O.size()*2 - 1)); //x.size for the data, and x.size*2-1 for the 0 padding
  outX = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) *(O.size() + O.size()*2 - 1)); //x.size for the data, and x.size*2-1 for the 0 padding

  inY = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * (O.size() + O.size()*2 - 1));
  outY = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) *(O.size() + O.size()*2 - 1));

  inZ = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * (O.size() + O.size()*2 - 1));
  outZ = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) *(O.size() + O.size()*2 - 1));

  pX = fftw_plan_dft_1d(O.size() + O.size()*2 - 1, inX, outX, FFTW_FORWARD, FFTW_ESTIMATE);
  pY = fftw_plan_dft_1d(O.size() + O.size()*2 - 1, inY, outY, FFTW_FORWARD, FFTW_ESTIMATE);
  pZ = fftw_plan_dft_1d(O.size() + O.size()*2 - 1, inZ, outZ, FFTW_BACKWARD, FFTW_ESTIMATE);

}

LightweightTimeslots::~LightweightTimeslots (void) {
  fftw_free(inX);
  fftw_free(inY);
  fftw_free(outX);
  fftw_free(outY);
  fftw_free(inZ);
  fftw_free(outZ);
}

/*void
LoRaWANNetworkServer::DoInitialize (void)
{
  NS_LOG_FUNCTION (this);

  Object::DoInitialize ();

  //this->m_lorawanLightweightTimeslotsPtr =  new LightweightTimeslots::LightweightTimeslots();


  LightweightTimeslots::m_lorawanLightweightTimeslotsPtr = CreateObject<LightweightTimeslots> ();
  LightweightTimeslots::m_lorawanLightweightTimeslotsPtr->Initialize ();

  m_lightweightTimeslotsPtr = LightweightTimeslots::m_lorawanLightweightTimeslotsPtr; //!< Pointer to singleton
}*/

void LightweightTimeslots::Run() {


  // run TiCom on each sequence, store output
  std::cout << "Starting TiCom!" << std::endl;
  auto start = std::chrono::high_resolution_clock::now();
  std::vector<std::tuple <int, int>> S = TiComWithAutocorrelation(O, alpha);
  auto finish = std::chrono::high_resolution_clock::now();
  std::cout << "Finished TiCom!" << std::endl;

  for(uint x=0;x<S.size();x++) {
    std::cout << round(std::get<0>(S[x])*slot_size) <<  " " << std::get<1>(S[x]) << std::endl;
  }
  std::chrono::duration<double> elapsed = finish - start;
  std::cout << "Elapsed time: " << elapsed.count() << " s\n";
  
  //each device has a sequence, and outputs a vector with elements in the format (p, o, uid, change). In the format Periodicity

  // TODO:
  // take code from collision_avoidance.py, convert to C++.
  // test collision prediction with randomised err data (false positives i.e. event-based data)
  // add this to ns-3 module

  std::vector<Periodicity> periodicities { 
    {200, 0, 1, 0}, 
    {200, 0, 2, 0}, 
    {200, 0, 3, 0}, 
    {200, 1, 4, 0}, 
    {200, 2, 5, 0},  
    {400, 2, 7, 0}, 
    {125, 5, 8, 0}, 
    {125, 3, 9, 0} 
  };
  CollisionAvoidance(periodicities, 0.2);
  for(uint i=0; i<periodicities.size(); i++) {
    std::cout << periodicities[i].p << " " << periodicities[i].o << " " << periodicities[i].change << std::endl;
  }
}

std::vector<std::tuple <int, int>> LightweightTimeslots::TiComWithAutocorrelation(std::vector<unsigned char>& O, float alpha) {
  std::vector<unsigned char> O_filter(O);

  std::tuple<int, int> s_candidate = FindCandidateSolutionAutocorrelation(O);
  int s_p = std::get<0>(s_candidate);
  int rough_o = std::get<1>(s_candidate);

  std::vector< std::tuple <int, int> > S(0);
  S.reserve(20);
  int search_space = 10;

  //check the 20 values around it TODO: this should be relative to the size of O.
  if(rough_o - search_space >= 0) {
    if(rough_o + search_space < s_p) {
      for(int i=rough_o - search_space;i< rough_o + search_space; i++) {
        S.push_back(std::tuple<int, int>(s_p, i));
      }
    } else {
      for(int i=rough_o - search_space; i<s_p; i++) {
        S.push_back(std::tuple<int, int>(s_p, i));
      }
      for(int i=0;i< rough_o + search_space - s_p; i++) {
        S.push_back(std::tuple<int, int>(s_p, i));
      }
    }
  } else {
    for(int i=0; i<rough_o + search_space; i++) {
      S.push_back(std::tuple<int, int>(s_p, i));
    }
    for(int i=s_p - rough_o - search_space;i< s_p; i++) {
      S.push_back(std::tuple<int, int>(s_p, i));
    }
  }

  float abs_T = 0;
  float abs_F = 0;
  for(uint x=0;x<O.size();x++) {
    if(O[x]) {
      abs_T++;
    }
    else{
      abs_F++;
    }
  }

  std::vector<std::tuple <int, int>> S_star(0); //S_star = [] #begins empty.
  S_star.reserve(10); //reserve enough space
  std::vector<unsigned char> Ps_star(O.size(), 0);  //Ps_star = [0] * len(O) #begins all 0

  //argmaxOverList
  float max_found = 0;
  int max_ind = 0;
  for(uint i=0; i<S.size(); i++) {
    float res = TiComScore(S.at(i), Ps_star, O, alpha, abs_T, abs_F);
    if (max_found < res) {
      max_found = res;
      max_ind = i;
    }
  }
  std::tuple <int, int> s = S.at(max_ind);
  float score = max_found;

  while (score > 0) { 
    S_star.push_back(std::tuple <int, int>(std::get<0>(s), std::get<1>(s)));

    int l = std::get<0>(s);
    int i = std::get<1>(s);

    int O_count = 0;
    for (int x=0; x<int(O.size()); x++) {
      if(x % l == i && Ps_star[x] == 0) {
        Ps_star[x] = 1;
        O_filter[x] = 0;
      }
      if(O_filter[x] == 1) {
        O_count++;
      }
    }

    //remove s pairs that are subsets of other pairs
    std::vector< std::tuple <int, int> > to_remove(0);
    to_remove.reserve(S_star.size());      

    for (uint x=0; x<S_star.size(); x++) {
      int l_dash = std::get<0>(S_star[x]);
      int i_dash = std::get<1>(S_star[x]);
      if(l_dash % l  == 0 && i_dash % l == i) {
        if (!(l_dash == l && i_dash == i)) {
          to_remove.push_back(S_star[x]);
        }
      }
    }
    for (uint x=0; x<to_remove.size(); x++) {
      S_star.erase(std::remove(S_star.begin(), S_star.end(), to_remove.at(x)), S_star.end());  // can prob. be done in a faster way       
    }

    if(O_count == 0) {
      //all places are covered, so we're finished
      break;
    }

    s_candidate = FindCandidateSolutionAutocorrelation(O_filter);
    s_p = std::get<0>(s_candidate);
    rough_o = std::get<1>(s_candidate);
    S.clear();

    //check the 20 values around it TODO: this should be relative to the size of O.
    if(rough_o - search_space >= 0) {
      if(rough_o + search_space < s_p) {
        for(int i=rough_o - search_space;i< rough_o + search_space; i++) {
          S.push_back(std::tuple<int, int>(s_p, i));
        }
      } else {
        for(int i=rough_o - search_space; i<s_p; i++) {
          S.push_back(std::tuple<int, int>(s_p, i));
        }
        for(int i=0;i< rough_o + search_space - s_p; i++) {
          S.push_back(std::tuple<int, int>(s_p, i));
        }
      }
    } else {
      for(int i=0; i<rough_o + search_space; i++) {
        S.push_back(std::tuple<int, int>(s_p, i));
      }
      for(int i=s_p - rough_o - search_space;i< s_p; i++) {
        S.push_back(std::tuple<int, int>(s_p, i));
      }
    }

    max_found = 0;
    max_ind = 0;
    for(uint i=0; i<S.size(); i++) {
      float res = TiComScore(S.at(i), Ps_star, O, alpha, abs_T, abs_F);
      if (max_found < res) {
       max_found = res;
       max_ind = i;
     }
   }
   s = S.at(max_ind);
   score = max_found;
 }

 return S_star;
}


float LightweightTimeslots::TiComScore(std::tuple <int, int> s, std::vector<unsigned char>& Ps_star, std::vector<unsigned char>& O, float alpha, float abs_T, float abs_F) {
    //abs_T is the count of 1s in O
    //abs_F is the count of -1s in O
    //abs_TPs is the count of how many 1s the candidate solution covers, that haven't already been covered by Ps_star
    //abs_FPs is the count of how many false positives the candidate solution provides, that haven't already been provided in Ps_star

  int l = std::get<0>(s);
  int i = std::get<1>(s);

  int abs_TPs = 0;
  int abs_FPs = 0;

  for(int x=0;x<int(O.size());x++) {

    if(O[x]==1 && x%l==i && Ps_star[x]==0) {
      abs_TPs++;
    } else if(O[x]==0 && x%l==i && Ps_star[x]==0) {
      abs_FPs++;
    }
  }
  return (1 - alpha)*((float) abs_TPs / (float) abs_T) - (alpha)*((float) abs_FPs / (float) abs_F);
} 



std::tuple<int, int> LightweightTimeslots::FindCandidateSolutionAutocorrelation(const std::vector<unsigned char>& O) {

  //autocorrelate the sequence to find a candidate periodicity
  Correlation(O, O, correlation_holder);

  float periodicity = 0.0;
  int start_point = correlation_holder.size() / 2;

  //choose the max value found
  float max_autoc = 0.0;
  for(uint i=start_point+1; i<correlation_holder.size();i++){
    if(correlation_holder[i] > max_autoc) {

      max_autoc = correlation_holder[i];
      periodicity = i - start_point;
    }
  }

  if(periodicity == 0) {
    return std::tuple<int, int>(1, 0);
  }

  // generate a sequence with that periodicity with the offset 0
  std::vector<unsigned char> O_copy2(O.size(), 0);
  for(uint i=0;i<O_copy2.size();i+=periodicity) {
    O_copy2[i] = 1;
  }
  

  //get the correlation of that sequence with the original sequence, and find the angle between them 
  Correlation(O, O_copy2, correlation_holder);
  float max = 0.0;
  int index = 0;
  for(uint i=start_point; i<correlation_holder.size();i++) {
    if(correlation_holder[i] > max) {
      max = correlation_holder[i];
      index = i-start_point;
    }
  }

  return std::tuple<int, int>(int(periodicity), index);
}

void LightweightTimeslots::Correlation(const std::vector<unsigned char>& x, const std::vector<unsigned char>& y, std::vector<float>& z)
{
  std::chrono::high_resolution_clock::time_point start, before, now, finish; 
  std::chrono::duration<double> elapsed;
  if(DEBUG) {
    start = std::chrono::high_resolution_clock::now();
    before = std::chrono::high_resolution_clock::now(); 
  }

  //put input data in to in inX and inY. Put y in backwards as this is correlation, not convolution
  
  int ysize = y.size();
  for(int i=0;i<ysize;i++) {
    inX[i][0] = x[i];
  }


  for(int i=0;i<ysize;i++) {
    inY[i][0] = y[ysize - 1 - i];
  }

  if(DEBUG) {
    now = std::chrono::high_resolution_clock::now();
    elapsed = now - before;
    std::cout << "Time to fill in x and y: " << elapsed.count() << " s\n";
    before = std::chrono::high_resolution_clock::now();
  }
  

  fftw_execute(pX);

  if(DEBUG) {
    now = std::chrono::high_resolution_clock::now();
    elapsed = now - before;
    std::cout << "Time to execute fft x: " << elapsed.count() << " s\n";
    before = std::chrono::high_resolution_clock::now();
  }
  

  fftw_execute(pY);

  if(DEBUG) {
    now = std::chrono::high_resolution_clock::now();
    elapsed = now - before;
    std::cout << "Time to execute fft y: " << elapsed.count() << " s\n";
    before = std::chrono::high_resolution_clock::now();
  }

  //perform element-wise multiplication of x and y (multiplying the complex numbers)
  //(x + yi)(u + vi) = (xu - yv) + (xv + yu)i
  for(uint i=0;i<x.size()*3 - 1;i++) {
    inZ[i][0] = (outX[i][0] * outY[i][0]) - (outX[i][1] * outY[i][1]);
    inZ[i][1] = (outX[i][0] * outY[i][1]) + (outX[i][1] * outY[i][0]);    
  }

  if(DEBUG) {
    now = std::chrono::high_resolution_clock::now();
    elapsed = now - before;
    std::cout << "Time to fill in inZ (complex calculations): " << elapsed.count() << " s\n";
    before = std::chrono::high_resolution_clock::now();
  }

  //get ifft of result
  fftw_execute(pZ);

  if(DEBUG) {
    now = std::chrono::high_resolution_clock::now();
    elapsed = now - before;
    std::cout << "Time to execute fft z: " << elapsed.count() << " s\n";
    before = std::chrono::high_resolution_clock::now();
  }

  for(uint i=0;i<z.size();i++) {
    z[i] = std::abs(std::complex<double>(outZ[i][0], outZ[i][1])) / (x.size()*3 - 1);
  }

  if(DEBUG) {
    now = std::chrono::high_resolution_clock::now();
    elapsed = now - before;
    std::cout << "Time to move z data out: " << elapsed.count() << " s\n";
    before = std::chrono::high_resolution_clock::now();

    finish = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double>  elapsed = finish - start;
    std::cout << "Elapsed time for correlation: " << elapsed.count() << " s\n\n";
  }
}

int LightweightTimeslots::Main(int argc, const char** argv) {
  LightweightTimeslots* lightweightTimeslots = new LightweightTimeslots();

  try {
    lightweightTimeslots->Run();
  } catch(std::exception &e) {
    std::cerr << e.what() << std::endl;
  }

  delete lightweightTimeslots;

  return 0;
}

void LightweightTimeslots::CollisionAvoidance(std::vector<Periodicity>& periodicities, float alpha) {
  //elements are in the format (p, o, uid, change)


  //sort by p, and then sort the sublists by o
  //full_list = sorted(full_list, key=itemgetter(0, 1))
  sort(periodicities.begin(), periodicities.end(), sortByPthenO);

  /*
    //move one sequence if it overlaps with another by more than alpha percent
    for i, x in enumerate(full_list):
      for j, y in enumerate(full_list[i+1:]):
        o = overlap(x[0], y[0], x[1], y[1])
        if o > alpha:
          y[1] += 1
          y[3] += 1
          //TODO: ensure y[3] doesn't exceed MAX_C
          //well, it can temporarilly if it gets fixed later.
  */
  for(uint i=0; i<periodicities.size(); i++) {
    for(uint j=i+1; j<periodicities.size(); j++) {
      int o = CalculatePercentageOverlap(periodicities[i].p, periodicities[j].p, periodicities[i].o, periodicities[j].o);

      if(o > alpha && periodicities[j].change < MAX_C) {
        std::cout << "overlap between (" << periodicities[i].p << ", " << periodicities[i].o << ") and ( " <<  periodicities[j].p << ", " << periodicities[j].o << ")" << std::endl;  
        periodicities[j].o++;
        periodicities[j].change++;

        for(uint k=0; k<periodicities.size(); k++) {
            //we have to move all the other periodicities of this device too
            //TODO: but this can also cause a new overlap? 
            if(periodicities[j].uID == periodicities[j].uID && j!=k) {
                  periodicities[k].o++;
                  periodicities[k].change++;

            }
        }
        //TODO: ensure periodicities[j].change doesn't exceed MAX_C
        //(though it can here temporarily if it gets fixed later)
      }
    }
  }


  /*
    //reorder to minimise number of changes
    for i, x in enumerate(full_list):
      for j, y in enumerate(full_list[i+1:]):
        if x[0] == y[0] and x[1] + y[3] == y[1] and x[3] + y[3] <= MAX_C:
          x[1] += y[3]
          x[3] += y[3]
          y[1] -= y[3]
          y[3] -= y[3]
  */

  for(uint i=0; i<periodicities.size(); i++) {
    std::cout << periodicities[i].p << " " << periodicities[i].o << " " << periodicities[i].change << std::endl;
  }
  std::cout << "now reorder" << std::endl;

  for(uint i=0; i<periodicities.size(); i++) {
    for(uint j=i+1; j<periodicities.size(); j++) {
        if(periodicities[i].p == periodicities[j].p 
          && periodicities[i].o + periodicities[j].change == periodicities[j].o
          && periodicities[i].change + periodicities[j].change  <= MAX_C) {
          periodicities[i].o += periodicities[j].change;
          periodicities[i].change += periodicities[j].change;
          periodicities[j].o -= periodicities[j].change;
          periodicities[j].change -= periodicities[j].change;
        } 
    }
  }

}

int LightweightTimeslots::lcm(int a, int b) {
  return a * b / std::__gcd(a, b);
}

float LightweightTimeslots::CalculatePercentageOverlap(int p1, int p2, int o1, int o2) {
  /*o = abs(o1 - o2)
  d = math.gcd(p1, p2)
  if o % d == 0:
    # there will be a shared member of the set
    # calculate the percentage overlap:
    return p2 / lcm(p1, p2)
  else:
    theres no overlap
    return 0.0*/

  int o = std::abs(o1 - o2);
  int d = std::__gcd(p1, p2);

  if(o % d == 0) {
    // there will be a shared member of the set
    // calculate the percentage overlap
    return p2 / lcm(p1, p2);
  } else {
    // there's no overlap
    return 0.0;
  }
}

bool LightweightTimeslots::sortByPthenO(Periodicity p1, Periodicity p2) {
  if(p1.p < p2.p) {
    return true;
  } else if (p1.p > p2.p) {
    return false;
  } else { // if p1 == p2
    return (p1.o < p2.o);
  }
}

} // namespace ns3
